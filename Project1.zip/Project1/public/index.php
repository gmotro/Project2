<?php
    // Load and launch the actual application
    require '../src/app.php';
