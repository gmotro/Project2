<?php

/**
 * DBLogin short summary.
 *
 * DBLogin description.
 *
 * @version 1.0
 * @author GennadiyM
 */
namespace Common\Authentication;
 
class DBLogin
{
    
    
    
}
